from django.contrib import admin
from.models import customer

# Register your models here.
admin.site.register(customer)
